@echo off
setlocal
cd /d "%~dp0"
rem Uso: gerar-certificado.bat 192.168.0.15   (IP do computador na rede; pode passar mais de um)
where mkcert >nul 2>nul
if errorlevel 1 echo mkcert nao encontrado. Instale com: winget install FiloSottile.mkcert  (depois abra um novo terminal) & exit /b 1
if "%~1"=="" echo Informe o IP do computador na rede. Exemplo: gerar-certificado.bat 192.168.0.15 & exit /b 1
if not exist certs mkdir certs
mkcert -install
mkcert -cert-file certs\cert.pem -key-file certs\key.pem localhost 127.0.0.1 ::1 %*
if errorlevel 1 echo Falha ao gerar o certificado. & exit /b 1
echo.
echo Certificado criado em certs\ (nao versione nem compartilhe esta pasta).
echo Para o celular confiar nele, copie SOMENTE o arquivo rootCA.pem da pasta abaixo:
mkcert -CAROOT
echo NUNCA envie o arquivo rootCA-key.pem para ninguem nem para o celular.
echo Passo a passo: docs\HTTPS-LOCAL.md
