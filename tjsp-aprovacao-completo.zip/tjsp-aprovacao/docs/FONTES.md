# Provas e gabaritos: de onde vêm

## Importar da sua pasta (recomendado)
`importar-provas.bat "C:\pasta\com\os\PDFs"` — lê PDFs com "prova" no nome (questões, **sem gabarito**) e com "gabarito" no nome
(guardados **sem vínculo**). É seguro repetir (idempotente por hash do arquivo).

Único vínculo automático: gabarito × prova de **02/07/2023**, conferido recalculando 4 questões de Matemática (71-E, 72-A, 74-D, 75-B).
Os demais exigem sua conferência na aba **Provas** (campo "como conferiu"), porque as provas antigas não trazem a versão/caderno:
- Gabarito de 2024 (4 versões, aplicação de 08/09/2024) **não** é o da prova "reaplicação capital V3" que você enviou — não vinculei.
- Gabarito de 28/05/2023 e de dez/2025 não têm prova correspondente nos arquivos. O de dez/2025 é **imagem** (70 questões, 4 versões): só será
  transcrito quando você enviar a prova de 2025, para conferir letra a letra.
- Provas 2018 e 2021 não têm gabarito nos arquivos (envie o oficial, informando versão/caderno).

## Busca na web e importação por endereço
- Busca usa a API oficial do Google (Programmable Search): crie uma chave e um mecanismo de busca e defina `GOOGLE_CSE_KEY` e `GOOGLE_CSE_CX`.
  Sem isso a busca fica desligada. O app **não raspa** o site do Google nem bancos comerciais de questões (termos de uso e direitos autorais).
- Importar por endereço: só `https`, só domínios permitidos (`vunesp.com.br`, `tjsp.jus.br`; adicione outros com `TJSP_FONTES_PERMITIDAS=dominio1,dominio2`),
  só IP público, PDF de até 30 MB, sem seguir redirecionamentos.
- Não testado contra os sites reais (sem rede no ambiente de construção). Se falhar, baixe o PDF e use o `.bat`.

## Estrutura 2026 × provas antigas
As provas antigas têm 100 questões e servem como banco e referência de **estilo** da VUNESP; o simulado completo segue os **70 do edital 2026**
(16/30/4/4/9/7). As questões de Direito antigas mapeiam para as 5 matérias de Direito; Legislação Interna não aparece nas provas antigas.
