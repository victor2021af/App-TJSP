# Arquitetura — TJSP Aprovação

## 1. Arquitetura recomendada

**PWA local-first com servidor único.** Um backend Python serve a API e o frontend compilado na mesma origem.
O navegador (PC ou celular) é só interface; **toda a memória do estudante vive no SQLite do servidor**.

```
 Celular (PWA) ──HTTPS──┐
                        ├──►  FastAPI  ──►  services/ (regras)  ──►  SQLite (backend/data/tjsp.db)
 PC (navegador/PWA) ────┘        │                                         ├─ backups/ (API de backup do SQLite)
                                 └─ serve frontend/dist                    └─ uploads/ (Fase 5)
```

Decisões:
- **Mesma origem** (API + frontend na mesma porta): simplifica HTTPS, CORS e a instalação do PWA.
- **Regras em `services/`**, independentes de HTTP: testáveis sem servidor (é por isso que 47 testes rodam sem FastAPI).
- **Camada fina de banco** (`db.py`) e SQL explícito em vez de ORM, para trocar de SQLite para PostgreSQL mexendo em
  poucos lugares.
- **Estado do cronômetro no servidor**: fechar a aba ou trocar de aparelho não perde tempo.

### Desvio consciente em relação ao pedido
O pedido sugeria SQLAlchemy + migrações. Usei **`sqlite3` da biblioteca padrão + migrações SQL versionadas próprias**
(`app/migrate.py`). Motivo: SQLAlchemy/Alembic não estavam instalados nem instaláveis no ambiente de construção, e eu
só quero entregar código que consegui executar. Consequência: a migração para PostgreSQL exigirá adaptar `db.py` e
alguns trechos de SQL (`INSERT … ON CONFLICT` e índices parciais funcionam no Postgres; a chave autoincremental
`INTEGER PRIMARY KEY` e o tratamento de datas como texto ISO podem precisar de ajuste). Se preferir SQLAlchemy +
Alembic desde já, a troca é viável agora, enquanto o código ainda é pequeno.

## 2. Estrutura de pastas

```
backend/
  app/
    main.py            app FastAPI, lifespan (migra, carrega edital, backup automático), segurança de cabeçalhos
    config.py db.py migrate.py errors.py deps.py
    routers/           saude, auth, conteudo, estudo, painel(+configuracoes+rede), backups
    services/          auth, estudo, conteudo, configuracoes, painel, backup, seed, auditoria
    migrations/        0001…0004 (núcleo, questões, gabaritos, IA)
    seed/              edital_2026.json (Anexo VIII)
  tests/               pytest (+ test_api.py, que exige fastapi/httpx)
frontend/
  src/ api.ts format.ts App.tsx main.tsx styles.css pages/{Acesso,Painel,Estudar,Conteudo,Ajustes}.tsx
  public/ manifest.webmanifest sw.js ícones
docs/  scripts *.bat
```

## 3. Tecnologias e justificativas

| Camada | Escolha | Por quê |
|---|---|---|
| Interface | React + TypeScript + Vite | Pedido; PWA instalável; tipagem pega erros de contrato com a API |
| PWA | manifest + `sw.js` manuais | Menos dependências; o service worker é curto e **não guarda `/api`** |
| API | FastAPI + Pydantic | Pedido; validação de entrada e documentação automática em `/docs` |
| Banco | SQLite (WAL) | Zero administração, um arquivo, ótimo para uso pessoal; backup consistente pela API nativa |
| Senhas | scrypt (stdlib) | Sem dependência extra; sal aleatório, comparação em tempo constante |
| Testes | pytest | Cobre as regras sem subir servidor |

## 4. Modelo de dados

**0001 — núcleo:** `usuarios`, `sessoes_login` (só hash do token), `configuracoes`, `blocos`, `disciplinas`,
`assuntos` (com `parent_id` para subassuntos e `texto_edital` original), `progresso_assunto` (6 status),
`sessoes_estudo` (tempo acumulado + `em_execucao_desde`; índice único impede 2 sessões abertas), `auditoria`.

**0002 — questões e avaliações:** `documentos`, `questoes`, `alternativas` (A–E), `tentativas`, `questoes_favoritas`,
`revisoes_agendadas`, `simulados`, `simulado_questoes`, `redacoes`.

Restrições que protegem as regras do projeto, aplicadas **no banco** (e testadas):
- questão `oficial` exige `documento_id` (nunca perde a fonte);
- `gabarito` pode ser `NULL` (não comprovado) mas, se existir, só A–E;
- `origem` ∈ {oficial, ia, manual}: questões de IA nunca se misturam às oficiais sem marca;
- `redacoes.nota_estimada` é documentada como estimativa do app, não nota da VUNESP.

## 5. Módulos e dependências

`seed → blocos/disciplinas/assuntos → progresso_assunto → painel`; `estudo → sessoes_estudo → painel`;
`backup` independente; `auth` só protege os routers quando `TJSP_AUTH=on` (padrão: desligado, uso pessoal local);
`seguranca.py` (validação de Host e de Content-Type) vale nos dois modos.
Próximos: `questoes` (importador de PDF) → `tentativas` → `revisao` → `professor_ia` → `redacao` → `simulados`.

## 6. Cronograma técnico (fases)

| Fase | Entrega | Situação |
|---|---|---|
| 1 Fundação | Estrutura, banco, migrações, auth, backup, PWA, scripts | **feita** (HTTP/frontend sem execução — ver README) |
| 2 Sistema de estudos | Painel, conteúdo, cronômetro, metas | **parcial**: falta agenda de revisões espaçadas, gráficos semanais/mensais, planejamento adaptativo, resumos/aulas por assunto |
| 3 Banco de questões | Importar PDFs, filtros, resolução, histórico, favoritas | **feita** (importador validado nos PDFs reais) |
| 4 Professor IA | Provedor de IA, memória contextual, quadrinhos | **feita** (API real não testada) |
| 5 Redação | Upload, correção com IA, critérios do edital | **feita**, sem recorte de imagem |
| 6 Simulados | 70 questões na distribuição do edital, métricas | **feita**; hospedagem não |

## 7. Riscos técnicos e limitações

1. **Código ainda não executado de ponta a ponta** (HTTP e frontend): ver README. É o risco nº 1 hoje.
2. **Importação das provas (Fase 3).** Achados verificados nos PDFs:
   - As 4 provas antigas têm **100 questões**, o edital de 2026 tem **70**: não são equivalentes em estrutura e a
     distribuição por disciplina precisa ser mapeada pelo conteúdo, não pela posição.
   - Questões numeradas `01.`…, alternativas `(A)`…`(E)` (100 de cada por prova: extração promissora), com **textos-base
     compartilhados** entre várias questões e **hifenização de fim de linha** (`pou-\npança`) a corrigir.
   - **Nenhum PDF de prova traz gabarito.** As ocorrências de "gabarito" são texto de instrução ou de uma questão. Logo,
     todas as questões importadas entrarão com `gabarito = NULL` e marcadas para revisão manual, até que você forneça
     o gabarito oficial. **Não vou inferir respostas.**
   - O texto extraído contém caracteres de marcação (`�`, tabulações) que o importador precisa normalizar.
3. **Redação:** o edital (Cap. XI) traz critérios próprios: escala de 0 a 40, aprovação com ≥ 24 (19,2 para as vagas
   reservadas), **quatro critérios** (tema, estrutura/coerência, língua, coesão), **12 situações de nota zero** (fuga
   ao tema/gênero, identificação, ≤ 7 linhas, < 8 linhas autorais contínuas, cópia da coletânea, lápis ou tinta de cor
   não permitida etc.) e regras de "texto não escrito". O corretor da Fase 5 deve usar **esses** critérios; o edital
   **não publica pontuação por critério**, então qualquer nota do app será rotulada "estimativa", nunca "nota VUNESP".
4. **Legislação interna e atualidades:** o edital cobre leis, resoluções e fatos de 2026 que **não estão nos arquivos**
   (só os números dos artigos). Conteúdo jurídico detalhado exigirá você anexar os textos legais; sem eles o app não
   deve "ensinar" de memória como se fosse fonte documental.
5. **Celular só acessa com o PC ligado** (dados no PC). Sincronização/hospedagem é etapa futura e exige revisão de
   segurança.
6. **Custos de IA:** as APIs de Claude/OpenAI são cobradas à parte das assinaturas.
7. **Backup no mesmo disco** protege de erro, não de falha de disco: copie `backend/data/backups` para nuvem/pendrive.

## 8. Estratégia PC e celular

Um único código responsivo: menu lateral no PC; barra inferior, botões ≥ 44 px e cronômetro grande no celular
(`@media (max-width: 800px)`). Instalação via Chrome ("Instalar app") ou Safari ("Adicionar à Tela de Início"),
exigindo HTTPS local — ver [HTTPS-LOCAL.md](HTTPS-LOCAL.md). O service worker guarda só HTML/JS/CSS/ícones; dados de
estudo vêm sempre do servidor, evitando versões divergentes entre aparelhos.
