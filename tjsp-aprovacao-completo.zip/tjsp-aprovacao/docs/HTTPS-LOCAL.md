# HTTPS local para usar no celular

**Por quê:** o navegador só permite instalar um PWA e registrar o service worker em contexto seguro: `https://`
ou `localhost`. Abrir `http://192.168.x.x:8000` no celular **não** conta como seguro; o app até abre, mas não
fica instalável. Por isso o modo rede usa HTTPS com um certificado local.

> Os passos abaixo não puderam ser testados no ambiente onde o projeto foi escrito. Os nomes de menu do
> Android/iOS variam por versão e fabricante. Se algo não bater, me diga o que aparece na tela.

## 1. Gerar o certificado (uma vez, no Windows)

1. Instale o mkcert: `winget install FiloSottile.mkcert` e abra um novo terminal.
2. Descubra o IP do computador na rede: `ipconfig` → "Endereço IPv4" do Wi-Fi (ex.: `192.168.0.15`).
3. Rode `gerar-certificado.bat 192.168.0.15`. Ele cria `certs\cert.pem` e `certs\key.pem`.
   - Se o IP do computador mudar (roteador reatribuiu), gere de novo com o IP novo. Reserve um IP fixo para este
     computador no roteador para evitar isso.

## 2. Fazer o celular confiar no certificado

O mkcert cria uma "autoridade" local. O celular precisa confiar nela **uma vez**.

1. O script mostra a pasta do `CAROOT`. Copie **apenas `rootCA.pem`** para o celular (cabo USB, Drive, e-mail para
   você mesmo).
2. **Nunca copie nem envie `rootCA-key.pem`**: quem tiver esse arquivo consegue forjar certificados que o seu
   celular aceitaria.
3. **Android:** Configurações → Segurança (ou "Segurança e privacidade") → Mais configurações de segurança →
   Criptografia e credenciais → Instalar um certificado → **Certificado de CA** → escolha `rootCA.pem`.
   O Chrome do Android passa a aceitar o endereço.
4. **iPhone:** abra o arquivo, instale o perfil (Ajustes → "Perfil baixado"), depois em
   Ajustes → Geral → Sobre → Ajustes de Certificado Confiável → ative a confiança total para o certificado do mkcert.

## 3. Iniciar e acessar

1. No computador: `iniciar-rede.bat`. Quando o Firewall do Windows perguntar, permita **somente redes privadas**.
2. No celular (mesma rede Wi-Fi): abra `https://192.168.0.15:8443` (use o seu IP; ele também aparece em Ajustes).
3. No Chrome do Android: menu ⋮ → **Instalar app**. No Safari do iPhone: Compartilhar →
   **Adicionar à Tela de Início**.

## Segurança — o que este modo faz e não faz

- **Por padrão não há senha.** Qualquer aparelho da sua rede Wi-Fi que abrir `https://SEU-IP:8443` acessa e altera os
  dados. Use só em rede de casa, com pessoas de confiança. Para exigir senha, use `iniciar-rede-com-senha.bat`.
- O servidor só responde a `localhost` e a IPs de rede privada (192.168.x.x, 10.x.x.x, 172.16–31.x.x) e só aceita pedidos
  que alteram dados em formato JSON: isso protege contra sites maliciosos abertos no seu navegador, mas **não** contra
  alguém na sua rede.
- Não é um serviço endurecido para a internet.
- **Não** faça redirecionamento de porta (port forwarding) no roteador e **não** use este modo em Wi-Fi público.
  Expor o app à internet exige outra configuração (domínio, certificado público, proxy reverso, revisão de segurança),
  prevista para a preparação de hospedagem (Fase 6).
- O computador precisa estar ligado e com o servidor aberto para o celular acessar. Os dados vivem **no computador**;
  o celular é só uma tela. Sincronização na nuvem é uma etapa futura.
