# IA (Professor, quadrinhos, redação)

As chaves ficam **só no servidor**, em variáveis de ambiente do Windows (nunca no navegador nem no banco):

```
setx TJSP_IA_PROVEDOR anthropic        (ou openai)
setx ANTHROPIC_API_KEY sua-chave       (ou OPENAI_API_KEY)
setx TJSP_IA_MODELO nome-do-modelo     (obrigatório; consulte o nome atual no painel do provedor)
```
Feche e abra o terminal e reinicie o app. Sem isso, as telas de IA mostram "IA não configurada" e o resto funciona.

- Uso de API é cobrado à parte da assinatura do chat.
- **Imagens de redação** só saem do seu computador quando você marca a autorização no envio (por redação).
- Tudo gerado por IA é rotulado como tal. Questões "oficiais" nunca são geradas por IA.
- Quadrinhos só são gerados para questões **com gabarito comprovado**; o gabarito oficial é passado à IA, que não o deduz.
- Redação: a IA recebe o trecho literal do edital (`backend/app/seed/redacao_criterios_edital.txt`). A nota é **estimativa**: o edital não publica pontuação por critério.
- Alternativa sem API: em Redações, "Copiar prompt" gera o texto para colar em qualquer chat.
- **Não testado** contra as APIs reais (sem rede/chave no ambiente de construção); testes usam um provedor falso. Se der erro HTTP, confira chave e nome do modelo.
